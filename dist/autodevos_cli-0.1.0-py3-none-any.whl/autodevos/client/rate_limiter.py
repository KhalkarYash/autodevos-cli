"""Client-side sliding-window rate limiter for remote LLM API calls."""
from __future__ import annotations

import asyncio
import collections
import time


class RateLimiter:
    """
    Sliding-window rate limiter that enforces a maximum number of
    requests per 60-second window.

    Usage::

        limiter = RateLimiter(requests_per_minute=60)
        await limiter.acquire()   # blocks until a slot is available
        # ... make the API call
    """

    def __init__(self, requests_per_minute: int) -> None:
        if requests_per_minute <= 0:
            raise ValueError("requests_per_minute must be a positive integer")
        self._rpm = requests_per_minute
        self._window = 60.0  # seconds
        self._request_times: collections.deque[float] = collections.deque()
        self._lock = asyncio.Lock()

    @property
    def requests_per_minute(self) -> int:
        return self._rpm

    async def acquire(self) -> None:
        """Block until a request slot is available, then consume it."""
        while True:
            async with self._lock:
                now = time.monotonic()

                # Evict timestamps that have fallen outside the rolling window.
                while (
                    self._request_times
                    and now - self._request_times[0] >= self._window
                ):
                    self._request_times.popleft()

                if len(self._request_times) < self._rpm:
                    self._request_times.append(now)
                    return  # slot acquired

                # All slots used — calculate how long until the oldest one expires.
                wait_time = self._window - (now - self._request_times[0])

            # Release the lock while waiting so other coroutines can check too.
            await asyncio.sleep(max(0.0, wait_time))
